﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace JOOTASHOP.Manager
{
    public class userData
    {
        public string name { get; set; }
        public string contact { get; set; }
        public string cnic { get; set; }
    }
}