﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using JOOTASHOP.Models;

namespace JOOTASHOP.Manager
{
    public class currrentStatus
    {
        
        public static int option { get; set; }
    }
}